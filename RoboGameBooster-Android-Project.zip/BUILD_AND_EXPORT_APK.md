# Robo Game Booster — Build & Download Real Android APK

This package is a complete, standalone **Native Android Kotlin + Jetpack Compose** project (`com.robogamebooster`, Compile/Target SDK 35, Min SDK 26).

---

## Method 1: Build & Download the APK Using ONLY Your Android Phone (No PC Needed)

You can compile this project into a real installable `.apk` for free using **GitHub Actions** directly from Chrome on your Android phone:

1. **Download the Project ZIP on Your Phone**
   - Tap **Download Complete Android Project (.ZIP)** in the **Android Source** tab to save `RoboGameBooster-Android-Project.zip` to your phone's `Downloads` folder.

2. **Extract the ZIP on Your Phone**
   - Open your phone's **Files** app (or **ZArchiver**), tap `RoboGameBooster-Android-Project.zip`, and choose **Extract here** so you can see the project files (`settings.gradle.kts`, `build.gradle.kts`, `app/`, `.github/workflows/android-apk.yml`).

3. **Create a Free GitHub Repository in Chrome**
   - Open `https://github.com` in Chrome on your phone (enable **Desktop site** from Chrome's `⋮` menu if needed for easier file upload).
   - Sign in (or create a free account) and tap **New** to create a repository named `robo-game-booster` (Public or Private) — check **Add a README file** and tap **Create repository**.

4. **Upload the Extracted Project Files**
   - Inside your new repository, tap **Add file → Upload files**.
   - Upload the extracted files and folders — OR, easiest on Android phone without folder-drag issues:
     - Tap **Code → Codespaces → Create codespace on main** (free tier works directly in Chrome on Android!).
     - Drag/upload `RoboGameBooster-Android-Project.zip` into the Codespace Explorer, open the built-in Terminal, and run:
       ```bash
       unzip -o RoboGameBooster-Android-Project.zip
       rm RoboGameBooster-Android-Project.zip
       git add .
       git commit -m "Add Robo Game Booster native Android project"
       git push origin main
       ```

5. **Run the Automatic APK Build in GitHub Actions**
   - Open your repository's **Actions** tab.
   - Tap **Build Robo Game Booster Android APK** (it starts automatically on push, or tap **Run workflow**).
   - Wait ~2–4 minutes for the green checkmark (it automatically runs unit tests, strict Android Lint, and builds both Debug and Release APKs on Ubuntu with JDK 17 + Android SDK 35).

6. **Download & Install the Real APK on Your Phone**
   - Tap the finished workflow run and scroll to **Artifacts**.
   - Tap **robo-game-booster-debug-apk** (or **robo-game-booster-release-apk**) to download the artifact ZIP to your phone.
   - Extract it in your **Files** app to reveal `app-debug.apk` (or `app-release.apk`).
   - Tap the `.apk` file → allow **Install unknown apps** when prompted → tap **Install**.

7. **Authorize Permissions After Installing**
   - Open **Robo Game Booster** → tap the **Settings** gear icon and grant:
     - **Usage Access** (BGMI & PUBG Global detection)
     - **Display Over Other Apps** (draggable Floating FPS Panel)
     - **Do Not Disturb** (Priority DND during Game Boost)
     - **Notification Permission** (Android 13–15 `specialUse` foreground service requirement)

---

## Method 2: Build Locally in Android Studio (PC / Mac)

1. Install **Android Studio Ladybug (2024.2.1+)** with **Android 15 (API 35)** SDK and **JDK 17**.
2. Extract `RoboGameBooster-Android-Project.zip` and open the folder in Android Studio (**File → Open**).
3. Wait for Gradle Sync (Gradle 8.9).
4. Build APK:
   - Debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`
   - Signed Release APK: **Build → Generate Signed App Bundle or APK → APK** → `app/build/outputs/apk/release/app-release.apk`

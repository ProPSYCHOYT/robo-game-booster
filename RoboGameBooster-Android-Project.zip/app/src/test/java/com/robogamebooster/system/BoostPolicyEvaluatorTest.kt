package com.robogamebooster.system

import com.robogamebooster.model.BatteryTelemetry
import com.robogamebooster.model.DeviceTelemetry
import com.robogamebooster.model.FpsTelemetry
import com.robogamebooster.model.MemoryTelemetry
import com.robogamebooster.model.PermissionStatus
import com.robogamebooster.model.RecommendationSeverity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BoostPolicyEvaluatorTest {

    @Test
    fun fpsTelemetry_defaultsToNA_andKeepsRefreshRateSeparate() {
        val fps = FpsTelemetry(actualFps = null, displayRefreshRateHz = 120f)
        assertEquals("N/A", fps.formattedActualFps)
        assertEquals("120 Hz", fps.formattedRefreshRate)
    }

    @Test
    fun highBatteryTemp_producesActionRequiredThermalRecommendation() {
        val telemetry = DeviceTelemetry(
            battery = BatteryTelemetry(percent = 74, temperatureCelsius = 42.3f, isCharging = false),
            memory = MemoryTelemetry(totalMb = 8192, availableMb = 3200, lowMemory = false)
        )
        val perms = PermissionStatus(
            usageAccessGranted = true,
            overlayGranted = true,
            dndAccessGranted = true,
            notificationsGranted = true
        )

        val recs = BoostPolicyEvaluator.evaluate(telemetry, perms, dndActivated = true)
        assertTrue(recs.any { it.severity == RecommendationSeverity.ACTION_REQUIRED && it.title.contains("42.3") })
        assertFalse(recs.any { it.detail.contains("overclock", ignoreCase = true) })
    }

    @Test
    fun missingDndPermission_requestsAuthorization() {
        val telemetry = DeviceTelemetry(
            battery = BatteryTelemetry(percent = 80, temperatureCelsius = 33.5f, isCharging = false),
            memory = MemoryTelemetry(totalMb = 8192, availableMb = 4096, lowMemory = false)
        )
        val perms = PermissionStatus(
            usageAccessGranted = true,
            overlayGranted = true,
            dndAccessGranted = false,
            notificationsGranted = true
        )

        val recs = BoostPolicyEvaluator.evaluate(telemetry, perms, dndActivated = false)
        assertTrue(recs.any { it.title.contains("Do Not Disturb") && it.severity == RecommendationSeverity.ACTION_REQUIRED })
    }
}

package com.robogamebooster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.robogamebooster.model.PermissionStatus
import com.robogamebooster.ui.theme.CyanGlow
import com.robogamebooster.ui.theme.CyanOptic
import com.robogamebooster.ui.theme.MutedSteel
import com.robogamebooster.ui.theme.PurpleNeon
import com.robogamebooster.ui.theme.SteelBorder
import com.robogamebooster.ui.theme.TitaniumSurface

@Composable
fun PermissionsScreen(
    permissions: PermissionStatus,
    onRequestUsageAccess: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestDnd: () -> Unit,
    onRequestNotifications: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "System Permissions",
                    color = Color(0xFFF1F5F9),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${permissions.grantedCount} of 4 permissions authorized",
                    color = MutedSteel,
                    fontSize = 13.sp
                )
            }
            OutlinedButton(onClick = onBack) {
                Text("Done", color = CyanGlow)
            }
        }

        PermissionRowCard(
            title = "Usage Access",
            androidPermission = "PACKAGE_USAGE_STATS",
            explanation = "Required to detect when BGMI or PUBG Global is running in the foreground so Robo Game Booster can display active game status.",
            granted = permissions.usageAccessGranted,
            actionLabel = if (permissions.usageAccessGranted) "Manage" else "Grant Access",
            onAction = onRequestUsageAccess
        )

        PermissionRowCard(
            title = "Display Over Other Apps",
            androidPermission = "SYSTEM_ALERT_WINDOW",
            explanation = "Required to render the draggable translucent Floating FPS Panel on top of supported games.",
            granted = permissions.overlayGranted,
            actionLabel = if (permissions.overlayGranted) "Manage" else "Allow Overlay",
            onAction = onRequestOverlay
        )

        PermissionRowCard(
            title = "Do Not Disturb",
            androidPermission = "ACCESS_NOTIFICATION_POLICY",
            explanation = "Allows the Game Boost button to turn on Android Priority Do Not Disturb mode and silence disruptive alerts while gaming.",
            granted = permissions.dndAccessGranted,
            actionLabel = if (permissions.dndAccessGranted) "Manage" else "Authorize DND",
            onAction = onRequestDnd
        )

        PermissionRowCard(
            title = "Notification Permission",
            androidPermission = "POST_NOTIFICATIONS (Android 13–15)",
            explanation = "Required by Android 15 foreground service policies to keep the Floating FPS Overlay service alive with a visible Stop action.",
            granted = permissions.notificationsGranted,
            actionLabel = if (permissions.notificationsGranted) "Settings" else "Allow Alerts",
            onAction = onRequestNotifications
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun PermissionRowCard(
    title: String,
    androidPermission: String,
    explanation: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(TitaniumSurface, RoundedCornerShape(14.dp))
            .border(
                width = 1.dp,
                color = if (granted) CyanOptic.copy(alpha = 0.45f) else SteelBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color(0xFFF1F5F9),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = androidPermission,
                    color = MutedSteel,
                    fontSize = 11.sp
                )
            }
            Text(
                text = if (granted) "GRANTED" else "REQUIRED",
                color = if (granted) CyanGlow else PurpleNeon,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Text(
            text = explanation,
            color = Color(0xFFCBD5E1),
            fontSize = 13.sp,
            lineHeight = 18.sp
        )

        Button(
            onClick = onAction,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (granted) Color(0xFF1A2538) else CyanOptic,
                contentColor = if (granted) Color(0xFFE2E8F0) else Color(0xFF041219)
            ),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(text = actionLabel, fontWeight = FontWeight.SemiBold)
        }
    }
}

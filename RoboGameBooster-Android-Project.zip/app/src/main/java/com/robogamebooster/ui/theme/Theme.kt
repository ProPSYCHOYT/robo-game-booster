package com.robogamebooster.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val ObsidianCanvas = Color(0xFF060911)
val TitaniumSurface = Color(0xFF0E1420)
val SteelBorder = Color(0xFF1F2B3E)
val CyanOptic = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF22D3EE)
val PurpleNeon = Color(0xFFA855F7)
val SilverArmor = Color(0xFFD4DCE8)
val MutedSteel = Color(0xFF8B9AB2)

private val RoboDarkColors = darkColorScheme(
    primary = CyanOptic,
    onPrimary = Color(0xFF041219),
    secondary = PurpleNeon,
    onSecondary = Color(0xFF190726),
    background = ObsidianCanvas,
    onBackground = Color(0xFFF1F5F9),
    surface = TitaniumSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF151E2E),
    onSurfaceVariant = MutedSteel,
    outline = SteelBorder
)

private val RoboTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        letterSpacing = 1.2.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = 0.4.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        letterSpacing = 0.6.sp
    )
)

@Composable
fun RoboGameBoosterTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RoboDarkColors,
        typography = RoboTypography,
        content = content
    )
}

package com.robogamebooster.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.robogamebooster.model.BoostReport
import com.robogamebooster.model.DeviceTelemetry
import com.robogamebooster.model.PermissionStatus
import com.robogamebooster.model.SupportedGame
import com.robogamebooster.service.FloatingFpsOverlayService
import com.robogamebooster.system.GameBoostController
import com.robogamebooster.system.PermissionHelper
import com.robogamebooster.system.SystemTelemetryMonitor
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

enum class DashboardSection {
    HOME,
    FPS_MONITOR,
    CPU_MONITOR,
    RAM_MONITOR,
    TEMP_MONITOR,
    GAME_LAUNCHER,
    PERMISSIONS
}

data class RoboUiState(
    val activeSection: DashboardSection = DashboardSection.HOME,
    val telemetry: DeviceTelemetry = DeviceTelemetry(),
    val permissions: PermissionStatus = PermissionStatus(),
    val selectedGame: SupportedGame = SupportedGame.BGMI,
    val isOverlayRunning: Boolean = false,
    val isBoostActive: Boolean = false,
    val latestBoostReport: BoostReport? = null,
    val robotSpeech: String = "System ready. Tap BOOST to check thermals, memory, and Do Not Disturb.",
    val statusHeadline: String = "SYSTEM READY"
)

class RoboGameBoosterViewModel(application: Application) : AndroidViewModel(application) {

    val permissionHelper = PermissionHelper(application.applicationContext)
    private val telemetryMonitor = SystemTelemetryMonitor(application.applicationContext, permissionHelper)
    private val boostController = GameBoostController(application.applicationContext, permissionHelper)

    private val _uiState = MutableStateFlow(RoboUiState())
    val uiState: StateFlow<RoboUiState> = _uiState.asStateFlow()

    private val idleMessages = listOf(
        "System ready. Tap BOOST to prepare Do Not Disturb and check thermals.",
        "Floating HUD reports real display Hz separately from actual FPS.",
        "Grant Usage Access so I can detect BGMI and PUBG Global automatically.",
        "Keeping battery temperature under 39°C helps maintain steady frame pacing."
    )
    private var messageIndex = 0

    init {
        refreshAll()
        viewModelScope.launch {
            FloatingFpsOverlayService.isRunning.collect { running ->
                _uiState.update { it.copy(isOverlayRunning = running) }
            }
        }
        viewModelScope.launch {
            while (isActive) {
                refreshAll()
                delay(2000L)
            }
        }
    }

    fun refreshAll() {
        val perms = permissionHelper.snapshot()
        val selected = _uiState.value.selectedGame
        val snapshot = telemetryMonitor.readTelemetry(selected)
        val headline = when {
            snapshot.detectedForegroundGame != null -> "${snapshot.detectedForegroundGame.shortName} DETECTED"
            _uiState.value.isBoostActive -> "BOOST PREPARED"
            else -> "SYSTEM READY"
        }
        _uiState.update {
            it.copy(
                permissions = perms,
                telemetry = snapshot,
                statusHeadline = headline
            )
        }
    }

    fun navigateTo(section: DashboardSection) {
        _uiState.update { it.copy(activeSection = section) }
    }

    fun selectGame(game: SupportedGame) {
        _uiState.update {
            it.copy(
                selectedGame = game,
                robotSpeech = "${game.shortName} profile selected. Ready for launch or floating HUD."
            )
        }
        refreshAll()
    }

    fun cycleRobotSpeech() {
        messageIndex = (messageIndex + 1) % idleMessages.size
        val state = _uiState.value
        val dynamicHint = when {
            !state.permissions.overlayGranted ->
                "Enable Display Over Other Apps to launch the draggable Floating FPS Panel."
            state.telemetry.battery.temperatureCelsius != null &&
                state.telemetry.battery.temperatureCelsius >= 40f ->
                "Battery is ${state.telemetry.battery.formattedTemperature}. Consider lowering screen brightness."
            else -> idleMessages[messageIndex]
        }
        _uiState.update { it.copy(robotSpeech = dynamicHint) }
    }

    fun executeBoost(openDeviceGamingSettings: Boolean = false) {
        refreshAll()
        val current = _uiState.value
        val report = boostController.runBoost(
            telemetry = current.telemetry,
            permissions = current.permissions,
            openDeviceGamingSettings = openDeviceGamingSettings
        )
        val speech = buildString {
            append(if (report.dndActivated) "Do Not Disturb enabled. " else "Review DND permission for distraction-free play. ")
            val ramText = report.availableRamMb?.let { "$it MB RAM free" } ?: "RAM checked"
            val tempText = report.batteryTempCelsius?.let { String.format(Locale.US, "%.1f°C", it) } ?: "Temp N/A"
            append("$ramText · $tempText.")
        }
        _uiState.update {
            it.copy(
                isBoostActive = true,
                latestBoostReport = report,
                robotSpeech = speech,
                statusHeadline = "BOOST PREPARED"
            )
        }
        refreshAll()
    }

    fun openDeviceGamingSettings() {
        executeBoost(openDeviceGamingSettings = true)
    }

    fun toggleFloatingOverlay(): Boolean {
        refreshAll()
        val state = _uiState.value
        if (state.isOverlayRunning) {
            FloatingFpsOverlayService.stop(getApplication())
            _uiState.update {
                it.copy(robotSpeech = "Floating FPS overlay closed.")
            }
            return true
        }

        if (!state.permissions.canStartOverlay) {
            _uiState.update {
                it.copy(
                    activeSection = DashboardSection.PERMISSIONS,
                    robotSpeech = "Grant Display Over Other Apps and Notification permission first."
                )
            }
            return false
        }

        FloatingFpsOverlayService.start(getApplication())
        _uiState.update {
            it.copy(robotSpeech = "Floating FPS overlay active. Drag it anywhere on screen.")
        }
        return true
    }

    fun launchSelectedGame(): Boolean {
        val pkg = _uiState.value.selectedGame.packageName
        val launchIntent: Intent? = getApplication<Application>()
            .packageManager
            .getLaunchIntentForPackage(pkg)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(launchIntent)
            _uiState.update {
                it.copy(robotSpeech = "Launching ${_uiState.value.selectedGame.shortName}.")
            }
            true
        } else {
            _uiState.update {
                it.copy(robotSpeech = "${_uiState.value.selectedGame.shortName} is not installed on this device.")
            }
            false
        }
    }
}

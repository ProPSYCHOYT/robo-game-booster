package com.robogamebooster.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.robogamebooster.ui.theme.CyanGlow
import com.robogamebooster.ui.theme.CyanOptic
import com.robogamebooster.ui.theme.PurpleNeon
import com.robogamebooster.ui.theme.TitaniumSurface
import kotlin.math.abs

/**
 * Custom 3D-shaded Jetpack Compose Canvas rig for the Robo Game Booster AI Companion.
 * Renders multi-layered metallic silver & obsidian armor plates, articulated forearms,
 * glowing cyan-blue optics with smooth gaze sweep and periodic natural blinking,
 * purple neon highlights, breathing animation, holographic pedestal, and speech bubble.
 */
@Composable
fun RobotMascot3D(
    speechMessage: String,
    isBoostActive: Boolean,
    onTapRobot: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "robot_idle_rig")

    val breathPhase by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )

    val eyeScanX by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3900, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "eye_scan"
    )

    // Periodic blink cycle: stays open for ~94% of each 4.2s loop, briefly blinks shut
    val blinkCycle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "eye_blink"
    )

    val reactorPulse by transition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1750, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "reactor"
    )

    val eyeOpenFraction = if (blinkCycle in 0.92f..0.98f) {
        val local = (blinkCycle - 0.95f) / 0.03f
        abs(local).coerceIn(0.14f, 1f)
    } else {
        1f
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Companion Speech Bubble
        Box(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .background(
                    color = TitaniumSurface.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(14.dp)
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        listOf(
                            CyanOptic.copy(alpha = 0.72f),
                            PurpleNeon.copy(alpha = 0.58f)
                        )
                    ),
                    shape = RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            AnimatedContent(
                targetState = speechMessage,
                transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(160)) },
                label = "speech_bubble"
            ) { msg ->
                Text(
                    text = msg,
                    color = Color(0xFFE2E8F0),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Canvas(
            modifier = Modifier
                .size(246.dp)
                .clickable(onClick = onTapRobot)
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val breathDy = breathPhase * (h * 0.022f)
            val headDy = breathDy * 1.18f
            val armSway = breathPhase * (w * 0.008f)

            // Grounded Holographic Pedestal & Ambient Energy Cast
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(
                        (if (isBoostActive) PurpleNeon else CyanOptic).copy(alpha = 0.38f * reactorPulse),
                        CyanOptic.copy(alpha = 0.09f),
                        Color.Transparent
                    ),
                    center = Offset(cx, h * 0.91f),
                    radius = w * 0.40f
                ),
                topLeft = Offset(cx - w * 0.40f, h * 0.83f),
                size = Size(w * 0.80f, h * 0.15f)
            )
            drawOval(
                color = CyanGlow.copy(alpha = 0.55f),
                topLeft = Offset(cx - w * 0.28f, h * 0.875f),
                size = Size(w * 0.56f, h * 0.062f),
                style = Stroke(width = 2.5f)
            )
            drawOval(
                color = PurpleNeon.copy(alpha = 0.40f),
                topLeft = Offset(cx - w * 0.34f, h * 0.865f),
                size = Size(w * 0.68f, h * 0.082f),
                style = Stroke(width = 1.5f)
            )

            // Metallic 3D-Shaded Armor Brushes
            val silverArmorBrush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFFF8FAFC),
                    Color(0xFFA8B8CE),
                    Color(0xFF334155),
                    Color(0xFFCBD5E1)
                ),
                start = Offset(cx - w * 0.26f, h * 0.10f),
                end = Offset(cx + w * 0.28f, h * 0.84f)
            )

            val obsidianArmorBrush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFF283347),
                    Color(0xFF0E1420),
                    Color(0xFF05080F)
                ),
                start = Offset(cx - w * 0.20f, h * 0.18f),
                end = Offset(cx + w * 0.22f, h * 0.86f)
            )

            // Articulated Forearms & Gauntlet Cuffs
            val forearmY = h * 0.64f + breathDy * 0.85f
            drawRoundRect(
                brush = obsidianArmorBrush,
                topLeft = Offset(cx - w * 0.33f - armSway, forearmY),
                size = Size(w * 0.11f, h * 0.16f),
                cornerRadius = CornerRadius(18f, 18f)
            )
            drawRoundRect(
                brush = obsidianArmorBrush,
                topLeft = Offset(cx + w * 0.22f + armSway, forearmY),
                size = Size(w * 0.11f, h * 0.16f),
                cornerRadius = CornerRadius(18f, 18f)
            )
            drawLine(
                color = CyanGlow.copy(alpha = 0.85f),
                start = Offset(cx - w * 0.32f - armSway, forearmY + h * 0.125f),
                end = Offset(cx - w * 0.23f - armSway, forearmY + h * 0.125f),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = CyanGlow.copy(alpha = 0.85f),
                start = Offset(cx + w * 0.23f + armSway, forearmY + h * 0.125f),
                end = Offset(cx + w * 0.32f + armSway, forearmY + h * 0.125f),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )

            // Shoulder Pauldrons (Left & Right)
            val shoulderY = h * 0.47f + breathDy
            drawRoundRect(
                brush = silverArmorBrush,
                topLeft = Offset(cx - w * 0.36f - armSway * 0.5f, shoulderY),
                size = Size(w * 0.17f, h * 0.20f),
                cornerRadius = CornerRadius(26f, 26f)
            )
            drawRoundRect(
                brush = silverArmorBrush,
                topLeft = Offset(cx + w * 0.19f + armSway * 0.5f, shoulderY),
                size = Size(w * 0.17f, h * 0.20f),
                cornerRadius = CornerRadius(26f, 26f)
            )

            // Purple Neon Shoulder Trim
            drawLine(
                color = PurpleNeon.copy(alpha = 0.92f),
                start = Offset(cx - w * 0.32f - armSway * 0.5f, shoulderY + h * 0.045f),
                end = Offset(cx - w * 0.25f - armSway * 0.5f, shoulderY + h * 0.145f),
                strokeWidth = 5f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = PurpleNeon.copy(alpha = 0.92f),
                start = Offset(cx + w * 0.32f + armSway * 0.5f, shoulderY + h * 0.045f),
                end = Offset(cx + w * 0.25f + armSway * 0.5f, shoulderY + h * 0.145f),
                strokeWidth = 5f,
                cap = StrokeCap.Round
            )

            // Torso Chassis (Obsidian Frame)
            val torsoTop = h * 0.46f + breathDy
            val torsoPath = Path().apply {
                moveTo(cx - w * 0.21f, torsoTop)
                lineTo(cx + w * 0.21f, torsoTop)
                lineTo(cx + w * 0.145f, torsoTop + h * 0.32f)
                lineTo(cx - w * 0.145f, torsoTop + h * 0.32f)
                close()
            }
            drawPath(path = torsoPath, brush = obsidianArmorBrush)
            drawPath(
                path = torsoPath,
                color = Color(0xFF475569),
                style = Stroke(width = 2.5f)
            )

            // Waist Purple Core Accent
            drawLine(
                color = PurpleNeon.copy(alpha = 0.78f),
                start = Offset(cx - w * 0.11f, torsoTop + h * 0.275f),
                end = Offset(cx + w * 0.11f, torsoTop + h * 0.275f),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )

            // Sculpted Silver Chest Armor Plates
            val chestPlateLeft = Path().apply {
                moveTo(cx - w * 0.195f, torsoTop + h * 0.02f)
                lineTo(cx - w * 0.02f, torsoTop + h * 0.06f)
                lineTo(cx - w * 0.045f, torsoTop + h * 0.195f)
                lineTo(cx - w * 0.165f, torsoTop + h * 0.145f)
                close()
            }
            val chestPlateRight = Path().apply {
                moveTo(cx + w * 0.195f, torsoTop + h * 0.02f)
                lineTo(cx + w * 0.02f, torsoTop + h * 0.06f)
                lineTo(cx + w * 0.045f, torsoTop + h * 0.195f)
                lineTo(cx + w * 0.165f, torsoTop + h * 0.145f)
                close()
            }
            drawPath(path = chestPlateLeft, brush = silverArmorBrush)
            drawPath(path = chestPlateRight, brush = silverArmorBrush)

            // Central AI Core Reactor
            val reactorCenter = Offset(cx, torsoTop + h * 0.14f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CyanGlow.copy(alpha = 0.90f * reactorPulse),
                        PurpleNeon.copy(alpha = 0.45f * reactorPulse),
                        Color.Transparent
                    ),
                    center = reactorCenter,
                    radius = w * 0.125f
                ),
                radius = w * 0.125f,
                center = reactorCenter
            )
            drawCircle(
                color = Color(0xFF0A101B),
                radius = w * 0.066f,
                center = reactorCenter
            )
            drawCircle(
                color = if (isBoostActive) PurpleNeon else CyanGlow,
                radius = w * 0.049f,
                center = reactorCenter,
                style = Stroke(width = 4f)
            )
            drawCircle(
                color = Color(0xFFE0F2FE),
                radius = w * 0.024f * reactorPulse,
                center = reactorCenter
            )

            // Articulated Neck Column
            drawRoundRect(
                brush = obsidianArmorBrush,
                topLeft = Offset(cx - w * 0.068f, h * 0.38f + headDy * 0.8f),
                size = Size(w * 0.136f, h * 0.10f),
                cornerRadius = CornerRadius(10f, 10f)
            )

            // Futuristic Metallic Head Helmet
            val headTop = h * 0.12f + headDy
            val headW = w * 0.45f
            val headH = h * 0.29f

            // Side Acoustic Fins with Purple Neon Edge Bars
            drawRoundRect(
                color = Color(0xFF1E293B),
                topLeft = Offset(cx - headW * 0.585f, headTop + headH * 0.24f),
                size = Size(w * 0.056f, headH * 0.50f),
                cornerRadius = CornerRadius(10f, 10f)
            )
            drawRoundRect(
                color = Color(0xFF1E293B),
                topLeft = Offset(cx + headW * 0.529f, headTop + headH * 0.24f),
                size = Size(w * 0.056f, headH * 0.50f),
                cornerRadius = CornerRadius(10f, 10f)
            )
            drawLine(
                color = PurpleNeon,
                start = Offset(cx - headW * 0.556f, headTop + headH * 0.33f),
                end = Offset(cx - headW * 0.556f, headTop + headH * 0.66f),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = PurpleNeon,
                start = Offset(cx + headW * 0.556f, headTop + headH * 0.33f),
                end = Offset(cx + headW * 0.556f, headTop + headH * 0.66f),
                strokeWidth = 4f,
                cap = StrokeCap.Round
            )

            // Sculpted Silver Cranium
            drawRoundRect(
                brush = silverArmorBrush,
                topLeft = Offset(cx - headW / 2f, headTop),
                size = Size(headW, headH),
                cornerRadius = CornerRadius(46f, 46f)
            )
            drawRoundRect(
                color = Color(0xFFE2E8F0).copy(alpha = 0.58f),
                topLeft = Offset(cx - headW / 2f, headTop),
                size = Size(headW, headH),
                cornerRadius = CornerRadius(46f, 46f),
                style = Stroke(width = 2.5f)
            )

            // Crown Purple Neon Ridge
            drawLine(
                color = PurpleNeon.copy(alpha = 0.90f),
                start = Offset(cx - w * 0.085f, headTop + headH * 0.11f),
                end = Offset(cx + w * 0.085f, headTop + headH * 0.11f),
                strokeWidth = 4.5f,
                cap = StrokeCap.Round
            )

            // Glossy Obsidian Visor Faceplate
            val visorW = headW * 0.82f
            val visorH = headH * 0.54f
            val visorLeft = cx - visorW / 2f
            val visorTop = headTop + headH * 0.27f

            drawRoundRect(
                brush = obsidianArmorBrush,
                topLeft = Offset(visorLeft, visorTop),
                size = Size(visorW, visorH),
                cornerRadius = CornerRadius(28f, 28f)
            )
            drawRoundRect(
                color = CyanOptic.copy(alpha = 0.68f),
                topLeft = Offset(visorLeft, visorTop),
                size = Size(visorW, visorH),
                cornerRadius = CornerRadius(28f, 28f),
                style = Stroke(width = 2f)
            )

            // Glowing Cyan-Blue Optics with Gaze Sweep & Natural Blink
            val gazeOffsetPx = eyeScanX * (visorW * 0.065f)
            val eyeY = visorTop + visorH * 0.5f
            val eyeHeight = (h * 0.030f) * eyeOpenFraction
            val leftEyeCenter = Offset(cx - visorW * 0.22f + gazeOffsetPx, eyeY)
            val rightEyeCenter = Offset(cx + visorW * 0.22f + gazeOffsetPx, eyeY)

            listOf(leftEyeCenter, rightEyeCenter).forEach { eyeCenter ->
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            CyanGlow.copy(alpha = 0.92f * eyeOpenFraction),
                            CyanOptic.copy(alpha = 0.35f * eyeOpenFraction),
                            Color.Transparent
                        ),
                        center = eyeCenter,
                        radius = w * 0.078f
                    ),
                    radius = w * 0.078f,
                    center = eyeCenter
                )
                drawRoundRect(
                    color = Color(0xFFE0F2FE),
                    topLeft = Offset(eyeCenter.x - w * 0.038f, eyeCenter.y - eyeHeight / 2f),
                    size = Size(w * 0.076f, eyeHeight),
                    cornerRadius = CornerRadius(12f, 12f)
                )
            }
        }
    }
}

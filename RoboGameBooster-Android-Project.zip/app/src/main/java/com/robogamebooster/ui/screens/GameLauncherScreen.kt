package com.robogamebooster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.robogamebooster.model.GameStatus
import com.robogamebooster.model.SupportedGame
import com.robogamebooster.ui.theme.CyanGlow
import com.robogamebooster.ui.theme.CyanOptic
import com.robogamebooster.ui.theme.MutedSteel
import com.robogamebooster.ui.theme.PurpleNeon
import com.robogamebooster.ui.theme.SteelBorder
import com.robogamebooster.ui.theme.TitaniumSurface

@Composable
fun GameLauncherPanel(
    games: List<GameStatus>,
    selectedGame: SupportedGame,
    usageAccessGranted: Boolean,
    onSelectGame: (SupportedGame) -> Unit,
    onLaunchSelectedGame: () -> Unit,
    onOpenPermissions: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Game Detection & Launcher",
            color = Color(0xFFF1F5F9),
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold
        )

        if (!usageAccessGranted) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TitaniumSurface, RoundedCornerShape(12.dp))
                    .border(1.dp, PurpleNeon.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Usage Access is required for live foreground game detection.",
                    color = Color(0xFFE2E8F0),
                    fontSize = 13.sp
                )
                OutlinedButton(onClick = onOpenPermissions) {
                    Text("Grant Usage Access", color = CyanGlow)
                }
            }
        }

        games.forEach { status ->
            val borderColor = when {
                status.isForeground -> CyanGlow
                status.isSelected -> PurpleNeon.copy(alpha = 0.7f)
                else -> SteelBorder
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TitaniumSurface, RoundedCornerShape(14.dp))
                    .border(1.dp, borderColor, RoundedCornerShape(14.dp))
                    .clickable { onSelectGame(status.game) }
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = status.game.displayName,
                        color = Color(0xFFF1F5F9),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = when {
                            status.isForeground -> "ACTIVE"
                            status.isInstalled -> "INSTALLED"
                            else -> "NOT INSTALLED"
                        },
                        color = when {
                            status.isForeground -> CyanGlow
                            status.isInstalled -> Color(0xFFCBD5E1)
                            else -> MutedSteel
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "${status.game.packageName} · ${status.game.regionLabel}",
                    color = MutedSteel,
                    fontSize = 12.sp
                )
            }
        }

        Button(
            onClick = onLaunchSelectedGame,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanOptic,
                contentColor = Color(0xFF041219)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "Launch ${selectedGame.shortName}",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

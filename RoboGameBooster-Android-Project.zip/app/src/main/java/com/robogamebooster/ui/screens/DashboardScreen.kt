package com.robogamebooster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.robogamebooster.model.BoostReport
import com.robogamebooster.model.RecommendationSeverity
import com.robogamebooster.ui.DashboardSection
import com.robogamebooster.ui.RoboUiState
import com.robogamebooster.ui.components.RobotMascot3D
import com.robogamebooster.ui.theme.CyanGlow
import com.robogamebooster.ui.theme.CyanOptic
import com.robogamebooster.ui.theme.MutedSteel
import com.robogamebooster.ui.theme.ObsidianCanvas
import com.robogamebooster.ui.theme.PurpleNeon
import com.robogamebooster.ui.theme.SteelBorder
import com.robogamebooster.ui.theme.TitaniumSurface

@Composable
fun DashboardScreen(
    uiState: RoboUiState,
    onSelectSection: (DashboardSection) -> Unit,
    onTapRobot: () -> Unit,
    onBoostClick: () -> Unit,
    onOpenGamingSettings: () -> Unit,
    onToggleOverlay: () -> Unit,
    onSelectGame: (com.robogamebooster.model.SupportedGame) -> Unit,
    onLaunchSelectedGame: () -> Unit,
    onOpenPermissions: () -> Unit
) {
    Scaffold(
        containerColor = ObsidianCanvas,
        topBar = {
            TopDashboardBar(
                batteryText = uiState.telemetry.battery.formattedPercent,
                isCharging = uiState.telemetry.battery.isCharging,
                onOpenPermissions = onOpenPermissions
            )
        },
        bottomBar = {
            BottomMonitorNavigation(
                activeSection = uiState.activeSection,
                onSelect = onSelectSection
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(6.dp))

            // Primary 3D Robot Mascot
            RobotMascot3D(
                speechMessage = uiState.robotSpeech,
                isBoostActive = uiState.isBoostActive,
                onTapRobot = onTapRobot
            )

            // Status Headline
            Text(
                text = uiState.statusHeadline,
                color = CyanGlow,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )

            // Large Circular BOOST Button
            Box(
                modifier = Modifier
                    .size(134.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                if (uiState.isBoostActive) PurpleNeon else CyanOptic,
                                Color(0xFF0A1628)
                            )
                        )
                    )
                    .border(
                        width = 2.dp,
                        brush = Brush.linearGradient(listOf(CyanGlow, PurpleNeon)),
                        shape = CircleShape
                    )
                    .clickable(onClick = onBoostClick),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "BOOST",
                        color = Color(0xFFF8FAFC),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.6.sp
                    )
                    Text(
                        text = if (uiState.isBoostActive) "RE-CHECK" else "PREPARE",
                        color = Color(0xFFCBD5E1),
                        fontSize = 10.sp,
                        letterSpacing = 1.2.sp
                    )
                }
            }

            // Floating FPS Overlay Control Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onToggleOverlay,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (uiState.isOverlayRunning) PurpleNeon else CyanOptic,
                        contentColor = Color(0xFF041219)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (uiState.isOverlayRunning) "Stop Floating HUD" else "Launch Floating HUD",
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onOpenGamingSettings,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Game Settings", color = CyanGlow)
                }
            }

            // Contextual Monitor / Launcher Detail Card
            when (uiState.activeSection) {
                DashboardSection.FPS_MONITOR -> {
                    MonitorDetailCard(
                        title = "FPS & Refresh Monitor",
                        rows = listOf(
                            "Actual Game FPS" to uiState.telemetry.fps.formattedActualFps,
                            "Display Refresh Rate" to uiState.telemetry.fps.formattedRefreshRate,
                            "DND Status" to if (uiState.telemetry.dndEnabled) "ON" else "OFF",
                            "Floating HUD" to if (uiState.isOverlayRunning) "RUNNING" else "STOPPED"
                        ),
                        footnote = uiState.telemetry.fps.fpsSourceNote
                    )
                }
                DashboardSection.CPU_MONITOR -> {
                    MonitorDetailCard(
                        title = "CPU Monitor",
                        rows = listOf(
                            "Logical Cores" to "${uiState.telemetry.cpu.logicalCores}",
                            "Current Clock" to (uiState.telemetry.cpu.currentClockMhz?.let { "$it MHz" } ?: "N/A (OS Restricted)"),
                            "Overclocking" to "Not supported (OS Protected)"
                        ),
                        footnote = "Clock reads come strictly from readable sysfs nodes; no fake frequencies are shown."
                    )
                }
                DashboardSection.RAM_MONITOR -> {
                    val mem = uiState.telemetry.memory
                    MonitorDetailCard(
                        title = "RAM Monitor",
                        rows = listOf(
                            "Available RAM" to (mem.availableMb?.let { "$it MB" } ?: "N/A"),
                            "Used RAM" to (mem.usedMb?.let { "$it MB (${mem.usedPercent ?: 0}%)" } ?: "N/A"),
                            "Total RAM" to (mem.totalMb?.let { "$it MB" } ?: "N/A"),
                            "Low Memory Flag" to if (mem.lowMemory) "HIGH PRESSURE" else "NORMAL"
                        ),
                        footnote = "Measured via Android ActivityManager.MemoryInfo."
                    )
                }
                DashboardSection.TEMP_MONITOR -> {
                    MonitorDetailCard(
                        title = "Thermal & Battery Monitor",
                        rows = listOf(
                            "Battery Temperature" to uiState.telemetry.battery.formattedTemperature,
                            "Battery Level" to uiState.telemetry.battery.formattedPercent,
                            "Power State" to if (uiState.telemetry.battery.isCharging) "Charging" else "On Battery"
                        ),
                        footnote = "Measured directly from BatteryManager.EXTRA_TEMPERATURE."
                    )
                }
                DashboardSection.GAME_LAUNCHER -> {
                    GameLauncherPanel(
                        games = uiState.telemetry.games,
                        selectedGame = uiState.selectedGame,
                        usageAccessGranted = uiState.permissions.usageAccessGranted,
                        onSelectGame = onSelectGame,
                        onLaunchSelectedGame = onLaunchSelectedGame,
                        onOpenPermissions = onOpenPermissions
                    )
                }
                else -> {
                    MonitorDetailCard(
                        title = "Live System Snapshot",
                        rows = listOf(
                            "Actual FPS / Refresh" to "${uiState.telemetry.fps.formattedActualFps} / ${uiState.telemetry.fps.formattedRefreshRate}",
                            "Available RAM" to (uiState.telemetry.memory.availableMb?.let { "$it MB" } ?: "N/A"),
                            "Battery Temp" to uiState.telemetry.battery.formattedTemperature,
                            "Selected Game" to uiState.selectedGame.shortName
                        ),
                        footnote = "Display refresh rate (Hz) is never reported as actual game FPS."
                    )
                }
            }

            // Latest Boost Report Recommendations
            uiState.latestBoostReport?.let { report ->
                BoostReportSection(report = report)
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun TopDashboardBar(
    batteryText: String,
    isCharging: Boolean,
    onOpenPermissions: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsidianCanvas)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "ROBO GAME BOOSTER",
            color = Color(0xFFF8FAFC),
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.4.sp
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = if (isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                contentDescription = "Battery",
                tint = CyanGlow,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = batteryText,
                color = Color(0xFFE2E8F0),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            IconButton(onClick = onOpenPermissions) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Permissions and Settings",
                    tint = Color(0xFFCBD5E1)
                )
            }
        }
    }
}

@Composable
private fun BottomMonitorNavigation(
    activeSection: DashboardSection,
    onSelect: (DashboardSection) -> Unit
) {
    NavigationBar(
        containerColor = TitaniumSurface,
        tonalElevation = 0.dp
    ) {
        val items = listOf(
            Triple(DashboardSection.FPS_MONITOR, "FPS", Icons.Default.Speed),
            Triple(DashboardSection.CPU_MONITOR, "CPU", Icons.Default.Memory),
            Triple(DashboardSection.RAM_MONITOR, "RAM", Icons.Default.Storage),
            Triple(DashboardSection.TEMP_MONITOR, "Temp", Icons.Default.Thermostat),
            Triple(DashboardSection.GAME_LAUNCHER, "Games", Icons.Default.SportsEsports)
        )

        items.forEach { (section, label, icon) ->
            val selected = activeSection == section
            NavigationBarItem(
                selected = selected,
                onClick = {
                    onSelect(if (selected) DashboardSection.HOME else section)
                },
                icon = { Icon(imageVector = icon, contentDescription = label) },
                label = { Text(text = label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CyanGlow,
                    selectedTextColor = CyanGlow,
                    unselectedIconColor = MutedSteel,
                    unselectedTextColor = MutedSteel,
                    indicatorColor = Color(0xFF152236)
                )
            )
        }
    }
}

@Composable
private fun MonitorDetailCard(
    title: String,
    rows: List<Pair<String, String>>,
    footnote: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .background(TitaniumSurface, RoundedCornerShape(14.dp))
            .border(1.dp, SteelBorder, RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = title,
            color = Color(0xFFF1F5F9),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
        rows.forEach { (label, value) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = label, color = MutedSteel, fontSize = 13.sp)
                Text(
                    text = value,
                    color = Color(0xFFF1F5F9),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        Text(
            text = footnote,
            color = MutedSteel,
            fontSize = 11.sp,
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun BoostReportSection(report: BoostReport) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .background(TitaniumSurface, RoundedCornerShape(14.dp))
            .border(1.dp, CyanOptic.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Optimization Recommendations",
            color = CyanGlow,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        report.recommendations.forEach { rec ->
            val accent = when (rec.severity) {
                RecommendationSeverity.OPTIMAL -> CyanGlow
                RecommendationSeverity.ADVISORY -> Color(0xFFFBBF24)
                RecommendationSeverity.ACTION_REQUIRED -> PurpleNeon
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = rec.title,
                    color = accent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = rec.detail,
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }
    }
}

package com.robogamebooster.model

import java.util.Locale

enum class SupportedGame(
    val displayName: String,
    val shortName: String,
    val packageName: String,
    val regionLabel: String
) {
    BGMI(
        displayName = "Battlegrounds Mobile India",
        shortName = "BGMI",
        packageName = "com.pubg.imobile",
        regionLabel = "India"
    ),
    PUBG_GLOBAL(
        displayName = "PUBG MOBILE Global",
        shortName = "PUBG Global",
        packageName = "com.tencent.ig",
        regionLabel = "Global"
    )
}

data class FpsTelemetry(
    val actualFps: Int? = null,
    val fpsSourceNote: String = "No real cross-app frame source available",
    val displayRefreshRateHz: Float? = null
) {
    val formattedActualFps: String
        get() = actualFps?.toString() ?: "N/A"

    val formattedRefreshRate: String
        get() = displayRefreshRateHz?.let { "${it.toInt()} Hz" } ?: "N/A"
}

data class MemoryTelemetry(
    val totalMb: Long? = null,
    val availableMb: Long? = null,
    val lowMemory: Boolean = false
) {
    val usedMb: Long?
        get() = if (totalMb != null && availableMb != null) {
            (totalMb - availableMb).coerceAtLeast(0L)
        } else {
            null
        }

    val usedPercent: Int?
        get() = if (totalMb != null && totalMb > 0L && usedMb != null) {
            ((usedMb!!.toDouble() / totalMb.toDouble()) * 100.0).toInt().coerceIn(0, 100)
        } else {
            null
        }
}

data class CpuTelemetry(
    val logicalCores: Int,
    val currentClockMhz: Int? = null
)

data class BatteryTelemetry(
    val percent: Int? = null,
    val temperatureCelsius: Float? = null,
    val isCharging: Boolean = false
) {
    val formattedPercent: String
        get() = percent?.let { "$it%" } ?: "N/A"

    val formattedTemperature: String
        get() = temperatureCelsius?.let { String.format(Locale.US, "%.1f°C", it) } ?: "N/A"
}

data class GameStatus(
    val game: SupportedGame,
    val isInstalled: Boolean,
    val isForeground: Boolean,
    val isSelected: Boolean
)

data class PermissionStatus(
    val usageAccessGranted: Boolean = false,
    val overlayGranted: Boolean = false,
    val dndAccessGranted: Boolean = false,
    val notificationsGranted: Boolean = false
) {
    val canStartOverlay: Boolean
        get() = overlayGranted && notificationsGranted

    val grantedCount: Int
        get() = listOf(
            usageAccessGranted,
            overlayGranted,
            dndAccessGranted,
            notificationsGranted
        ).count { it }
}

data class DeviceTelemetry(
    val fps: FpsTelemetry = FpsTelemetry(),
    val memory: MemoryTelemetry = MemoryTelemetry(),
    val cpu: CpuTelemetry = CpuTelemetry(logicalCores = Runtime.getRuntime().availableProcessors()),
    val battery: BatteryTelemetry = BatteryTelemetry(),
    val dndEnabled: Boolean = false,
    val detectedForegroundGame: SupportedGame? = null,
    val games: List<GameStatus> = emptyList()
)

data class BoostRecommendation(
    val title: String,
    val detail: String,
    val severity: RecommendationSeverity
)

enum class RecommendationSeverity {
    OPTIMAL,
    ADVISORY,
    ACTION_REQUIRED
}

data class BoostReport(
    val executedAtMillis: Long,
    val dndActivated: Boolean,
    val openedGamingSettings: Boolean,
    val settingsIntentLabel: String,
    val availableRamMb: Long?,
    val totalRamMb: Long?,
    val batteryTempCelsius: Float?,
    val recommendations: List<BoostRecommendation>
)

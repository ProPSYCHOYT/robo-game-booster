package com.robogamebooster

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.robogamebooster.ui.DashboardSection
import com.robogamebooster.ui.RoboGameBoosterViewModel
import com.robogamebooster.ui.screens.DashboardScreen
import com.robogamebooster.ui.screens.PermissionsScreen
import com.robogamebooster.ui.theme.RoboGameBoosterTheme

class MainActivity : ComponentActivity() {

    private val viewModel: RoboGameBoosterViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshAll()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            RoboGameBoosterTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                if (uiState.activeSection == DashboardSection.PERMISSIONS) {
                    PermissionsScreen(
                        permissions = uiState.permissions,
                        onRequestUsageAccess = {
                            startActivity(viewModel.permissionHelper.buildUsageAccessIntent())
                        },
                        onRequestOverlay = {
                            startActivity(viewModel.permissionHelper.buildOverlayPermissionIntent())
                        },
                        onRequestDnd = {
                            startActivity(viewModel.permissionHelper.buildDndAccessIntent())
                        },
                        onRequestNotifications = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                !viewModel.permissionHelper.hasNotificationPermission()
                            ) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                startActivity(viewModel.permissionHelper.buildNotificationSettingsIntent())
                            }
                        },
                        onBack = { viewModel.navigateTo(DashboardSection.HOME) }
                    )
                } else {
                    DashboardScreen(
                        uiState = uiState,
                        onSelectSection = viewModel::navigateTo,
                        onTapRobot = viewModel::cycleRobotSpeech,
                        onBoostClick = { viewModel.executeBoost(openDeviceGamingSettings = false) },
                        onOpenGamingSettings = viewModel::openDeviceGamingSettings,
                        onToggleOverlay = { viewModel.toggleFloatingOverlay() },
                        onSelectGame = viewModel::selectGame,
                        onLaunchSelectedGame = { viewModel.launchSelectedGame() },
                        onOpenPermissions = { viewModel.navigateTo(DashboardSection.PERMISSIONS) }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshAll()
    }
}

package com.robogamebooster.service

import android.annotation.SuppressLint
import android.app.ForegroundServiceStartNotAllowedException
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.robogamebooster.MainActivity
import com.robogamebooster.R
import com.robogamebooster.system.PermissionHelper
import com.robogamebooster.system.SystemTelemetryMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Android 15 (SDK 35) compliant Foreground Service rendering a permission-gated,
 * draggable translucent black Floating FPS Panel with a glowing cyan border.
 *
 * Strictly enforces honest telemetry:
 * - Actual FPS displays "N/A" because Android sandboxes third-party game frame buffers.
 * - Display Refresh Rate is reported separately in Hz.
 */
class FloatingFpsOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var pollingJob: Job? = null

    private lateinit var windowManager: WindowManager
    private lateinit var permissionHelper: PermissionHelper
    private lateinit var telemetryMonitor: SystemTelemetryMonitor

    private var overlayRoot: LinearLayout? = null
    private var metricsContainer: LinearLayout? = null
    private var minimizeButton: TextView? = null
    private var fpsValueView: TextView? = null
    private var refreshValueView: TextView? = null
    private var tempValueView: TextView? = null
    private var batteryValueView: TextView? = null
    private var dndValueView: TextView? = null

    private var isMinimized: Boolean = false
    private lateinit var layoutParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        permissionHelper = PermissionHelper(applicationContext)
        telemetryMonitor = SystemTelemetryMonitor(applicationContext, permissionHelper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Strict permission gate before entering foreground or attaching overlay
        if (!Settings.canDrawOverlays(this) || !permissionHelper.hasNotificationPermission()) {
            _isRunning.value = false
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = createForegroundNotification()
        val fgsStarted = try {
            val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                0
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, serviceType)
            true
        } catch (e: SecurityException) {
            false
        } catch (e: RuntimeException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                e is ForegroundServiceStartNotAllowedException
            ) {
                false
            } else {
                false
            }
        }

        if (!fgsStarted) {
            _isRunning.value = false
            stopSelf()
            return START_NOT_STICKY
        }

        if (overlayRoot == null) {
            attachOverlayWindow()
        }
        startTelemetryPolling()
        _isRunning.value = true
        return START_STICKY
    }

    override fun onDestroy() {
        pollingJob?.cancel()
        serviceScope.cancel()
        detachOverlayWindow()
        _isRunning.value = false
        super.onDestroy()
    }

    private fun createForegroundNotification(): Notification {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.overlay_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.overlay_channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingFpsOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_robo_hud)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Close Overlay", stopIntent)
            .build()
    }

    private fun attachOverlayWindow() {
        val density = resources.displayMetrics.density
        val padH = (12 * density).toInt()
        val padV = (8 * density).toInt()
        val strokePx = (1.5f * density).toInt().coerceAtLeast(2)

        val panelBackground = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 14f * density
            setColor(Color.argb(232, 6, 10, 18))
            setStroke(strokePx, Color.parseColor("#06B6D4"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBackground
            setPadding(padH, padV, padH, padV)
            elevation = 12f * density
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleView = TextView(this).apply {
            text = "ROBO HUD"
            setTextColor(Color.parseColor("#22D3EE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val minBtn = createControlButton("–") {
            toggleMinimized()
        }
        val closeBtn = createControlButton("×") {
            stopSelf()
        }
        minimizeButton = minBtn

        headerRow.addView(titleView)
        headerRow.addView(minBtn)
        headerRow.addView(closeBtn)
        root.addView(headerRow)

        val metricsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (6 * density).toInt(), 0, 0)
        }

        val (fpsRow, fpsVal) = createMetricRow("FPS", "N/A", "#22D3EE")
        val (hzRow, hzVal) = createMetricRow("Refresh", "N/A", "#E2E8F0")
        val (tempRow, tempVal) = createMetricRow("Temp", "N/A", "#C084FC")
        val (batRow, batVal) = createMetricRow("Battery", "N/A", "#E2E8F0")
        val (dndRow, dndVal) = createMetricRow("DND", "OFF", "#94A3B8")

        fpsValueView = fpsVal
        refreshValueView = hzVal
        tempValueView = tempVal
        batteryValueView = batVal
        dndValueView = dndVal

        metricsBox.addView(fpsRow)
        metricsBox.addView(hzRow)
        metricsBox.addView(tempRow)
        metricsBox.addView(batRow)
        metricsBox.addView(dndRow)
        metricsContainer = metricsBox

        root.addView(metricsBox)

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = (120 * density).toInt()
        }

        attachDragHandler(root)

        overlayRoot = root
        windowManager.addView(root, layoutParams)
    }

    private fun createControlButton(symbol: String, onClick: () -> Unit): TextView {
        val density = resources.displayMetrics.density
        return TextView(this).apply {
            text = symbol
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = (28 * density).toInt()
            minHeight = (28 * density).toInt()
            setPadding((6 * density).toInt(), 0, (6 * density).toInt(), 0)
            setOnClickListener { onClick() }
        }
    }

    private fun createMetricRow(
        label: String,
        initialValue: String,
        valueHexColor: String
    ): Pair<LinearLayout, TextView> {
        val density = resources.displayMetrics.density
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, (2 * density).toInt(), 0, (2 * density).toInt())
        }

        val labelView = TextView(this).apply {
            text = "$label:"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            minWidth = (64 * density).toInt()
        }

        val valueView = TextView(this).apply {
            text = initialValue
            setTextColor(Color.parseColor(valueHexColor))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.END
            minWidth = (68 * density).toInt()
        }

        row.addView(labelView)
        row.addView(valueView)
        return row to valueView
    }

    private fun toggleMinimized() {
        isMinimized = !isMinimized
        metricsContainer?.visibility = if (isMinimized) View.GONE else View.VISIBLE
        minimizeButton?.text = if (isMinimized) "+" else "–"
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDragHandler(targetView: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var dragging = false

        targetView.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 4 || abs(dy) > 4) {
                        dragging = true
                    }
                    layoutParams.x = initialX + dx
                    layoutParams.y = initialY + dy
                    if (overlayRoot != null) {
                        windowManager.updateViewLayout(overlayRoot, layoutParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        view.performClick()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun startTelemetryPolling() {
        pollingJob?.cancel()
        pollingJob = serviceScope.launch {
            while (isActive) {
                val snapshot = telemetryMonitor.readTelemetry(selectedGame = null)
                fpsValueView?.text = snapshot.fps.formattedActualFps
                refreshValueView?.text = snapshot.fps.formattedRefreshRate
                tempValueView?.text = snapshot.battery.formattedTemperature
                batteryValueView?.text = snapshot.battery.formattedPercent
                dndValueView?.text = if (snapshot.dndEnabled) "ON" else "OFF"
                dndValueView?.setTextColor(
                    Color.parseColor(if (snapshot.dndEnabled) "#22D3EE" else "#94A3B8")
                )
                delay(1500L)
            }
        }
    }

    private fun detachOverlayWindow() {
        overlayRoot?.let { view ->
            runCatching { windowManager.removeView(view) }
        }
        overlayRoot = null
    }

    companion object {
        private const val CHANNEL_ID = "robo_floating_fps_overlay"
        private const val NOTIFICATION_ID = 4101
        const val ACTION_START = "com.robogamebooster.action.START_OVERLAY"
        const val ACTION_STOP = "com.robogamebooster.action.STOP_OVERLAY"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, FloatingFpsOverlayService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingFpsOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}

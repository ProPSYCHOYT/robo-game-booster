package com.robogamebooster.system

import android.app.NotificationManager
import android.content.Context
import com.robogamebooster.model.BoostRecommendation
import com.robogamebooster.model.BoostReport
import com.robogamebooster.model.DeviceTelemetry
import com.robogamebooster.model.PermissionStatus
import com.robogamebooster.model.RecommendationSeverity
import java.util.Locale

/**
 * Pure, unit-testable evaluator that inspects genuine RAM, thermal, and permission state
 * to produce honest gaming recommendations without claiming CPU/GPU overclocking.
 */
object BoostPolicyEvaluator {

    fun evaluate(
        telemetry: DeviceTelemetry,
        permissions: PermissionStatus,
        dndActivated: Boolean
    ): List<BoostRecommendation> {
        val list = mutableListOf<BoostRecommendation>()

        val temp = telemetry.battery.temperatureCelsius
        when {
            temp == null -> list += BoostRecommendation(
                title = "Thermal sensor unavailable",
                detail = "Battery temperature could not be read on this device.",
                severity = RecommendationSeverity.ADVISORY
            )
            temp >= 41.0f -> list += BoostRecommendation(
                title = "High battery temperature (${String.format(Locale.US, "%.1f°C", temp)})",
                detail = "Thermal throttling is likely. Lower display brightness, remove thick phone cases, and avoid charging while playing.",
                severity = RecommendationSeverity.ACTION_REQUIRED
            )
            temp >= 37.5f -> list += BoostRecommendation(
                title = "Warm thermal state (${String.format(Locale.US, "%.1f°C", temp)})",
                detail = "Temperature is rising. Keep airflow clear and cap in-game graphics quality to preserve steady frame pacing.",
                severity = RecommendationSeverity.ADVISORY
            )
            else -> list += BoostRecommendation(
                title = "Thermal headroom healthy (${String.format(Locale.US, "%.1f°C", temp)})",
                detail = "Battery temperature is within normal gaming limits.",
                severity = RecommendationSeverity.OPTIMAL
            )
        }

        val usedPct = telemetry.memory.usedPercent
        val availMb = telemetry.memory.availableMb
        when {
            telemetry.memory.lowMemory || (usedPct != null && usedPct >= 82) -> list += BoostRecommendation(
                title = "High RAM pressure (${availMb ?: 0} MB free)",
                detail = "Close heavy background apps from Android Recents before launching BGMI or PUBG Global to reduce frame stutters.",
                severity = RecommendationSeverity.ACTION_REQUIRED
            )
            usedPct != null -> list += BoostRecommendation(
                title = "Available RAM: ${availMb ?: 0} MB ($usedPct% used)",
                detail = "Memory headroom looks healthy. Android manages background processes automatically without unsafe task killing.",
                severity = RecommendationSeverity.OPTIMAL
            )
        }

        if (telemetry.battery.isCharging && (temp ?: 0f) >= 36.0f) {
            list += BoostRecommendation(
                title = "Unplug charger during intensive play",
                detail = "Charging generates extra heat that can trigger earlier SoC thermal throttling.",
                severity = RecommendationSeverity.ADVISORY
            )
        }

        if (!permissions.dndAccessGranted) {
            list += BoostRecommendation(
                title = "Do Not Disturb access not granted",
                detail = "Grant Do Not Disturb access in Permissions so Game Boost can silence incoming notifications automatically.",
                severity = RecommendationSeverity.ACTION_REQUIRED
            )
        } else if (dndActivated) {
            list += BoostRecommendation(
                title = "Do Not Disturb enabled",
                detail = "Priority interruption filter is active to block disruptive heads-up notifications.",
                severity = RecommendationSeverity.OPTIMAL
            )
        }

        if (!permissions.usageAccessGranted) {
            list += BoostRecommendation(
                title = "Usage Access required for game detection",
                detail = "Enable Usage Access to automatically detect when BGMI or PUBG Global enters the foreground.",
                severity = RecommendationSeverity.ADVISORY
            )
        }

        return list
    }
}

/**
 * Executes safe, policy-compliant Game Boost preparation:
 * - Verifies permissions
 * - Activates Do Not Disturb if authorized
 * - Opens available system gaming/performance settings when requested
 * - Evaluates real RAM and battery temperature to produce honest recommendations
 * - Never claims to overclock CPU/GPU or fabricate hardware boosts
 */
class GameBoostController(
    private val context: Context,
    private val permissionHelper: PermissionHelper
) {

    fun runBoost(
        telemetry: DeviceTelemetry,
        permissions: PermissionStatus,
        openDeviceGamingSettings: Boolean
    ): BoostReport {
        val dndActivated = if (permissions.dndAccessGranted) {
            enableDoNotDisturb()
        } else {
            false
        }

        var openedSettings = false
        val (settingsIntent, settingsLabel) = permissionHelper.resolveGamingSettingsIntent()
        if (openDeviceGamingSettings) {
            openedSettings = runCatching {
                context.startActivity(settingsIntent)
                true
            }.getOrDefault(false)
        }

        val recommendations = BoostPolicyEvaluator.evaluate(
            telemetry = telemetry,
            permissions = permissions,
            dndActivated = dndActivated
        )

        return BoostReport(
            executedAtMillis = System.currentTimeMillis(),
            dndActivated = dndActivated,
            openedGamingSettings = openedSettings,
            settingsIntentLabel = settingsLabel,
            availableRamMb = telemetry.memory.availableMb,
            totalRamMb = telemetry.memory.totalMb,
            batteryTempCelsius = telemetry.battery.temperatureCelsius,
            recommendations = recommendations
        )
    }

    fun enableDoNotDisturb(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return false
        if (!nm.isNotificationPolicyAccessGranted) return false
        return runCatching {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            true
        }.getOrDefault(false)
    }

    fun disableDoNotDisturb(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return false
        if (!nm.isNotificationPolicyAccessGranted) return false
        return runCatching {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            true
        }.getOrDefault(false)
    }
}

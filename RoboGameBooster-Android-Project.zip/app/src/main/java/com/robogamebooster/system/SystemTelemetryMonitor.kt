package com.robogamebooster.system

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.view.Display
import com.robogamebooster.model.BatteryTelemetry
import com.robogamebooster.model.CpuTelemetry
import com.robogamebooster.model.DeviceTelemetry
import com.robogamebooster.model.FpsTelemetry
import com.robogamebooster.model.GameStatus
import com.robogamebooster.model.MemoryTelemetry
import com.robogamebooster.model.SupportedGame
import java.io.File

/**
 * Reads genuine Android device telemetry strictly from supported public APIs.
 *
 * FPS POLICY:
 * - Never fabricates or estimates fake game FPS.
 * - Standard Android apps cannot read another game's SurfaceFlinger frame rate without
 *   privileged instrumentation. Therefore `actualFps` remains null ("N/A") unless a
 *   supported real frame measurement source is attached.
 * - Display refresh rate (Hz) is always queried and reported independently.
 */
class SystemTelemetryMonitor(
    private val context: Context,
    private val permissionHelper: PermissionHelper
) {

    fun readTelemetry(selectedGame: SupportedGame?): DeviceTelemetry {
        val battery = readBatteryTelemetry()
        val memory = readMemoryTelemetry()
        val cpu = readCpuTelemetry()
        val refreshRateHz = readDisplayRefreshRateHz()
        val dndEnabled = readDndState()
        val foregroundGame = if (permissionHelper.hasUsageAccess()) {
            detectForegroundSupportedGame()
        } else {
            null
        }

        val gameStatuses = SupportedGame.entries.map { game ->
            GameStatus(
                game = game,
                isInstalled = isPackageInstalled(game.packageName),
                isForeground = foregroundGame == game,
                isSelected = selectedGame == game
            )
        }

        return DeviceTelemetry(
            fps = FpsTelemetry(
                actualFps = null,
                fpsSourceNote = "Android isolates third-party game frame buffers; showing N/A instead of simulated FPS.",
                displayRefreshRateHz = refreshRateHz
            ),
            memory = memory,
            cpu = cpu,
            battery = battery,
            dndEnabled = dndEnabled,
            detectedForegroundGame = foregroundGame,
            games = gameStatuses
        )
    }

    fun readBatteryTelemetry(): BatteryTelemetry {
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return BatteryTelemetry()

        val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) {
            ((level.toFloat() / scale.toFloat()) * 100f).toInt().coerceIn(0, 100)
        } else {
            null
        }

        val tempTenths = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temperatureCelsius = if (tempTenths != Int.MIN_VALUE && tempTenths > -500) {
            tempTenths / 10f
        } else {
            null
        }

        val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        return BatteryTelemetry(
            percent = percent,
            temperatureCelsius = temperatureCelsius,
            isCharging = isCharging
        )
    }

    fun readMemoryTelemetry(): MemoryTelemetry {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return MemoryTelemetry()
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalMb = memInfo.totalMem / (1024L * 1024L)
        val availableMb = memInfo.availMem / (1024L * 1024L)
        return MemoryTelemetry(
            totalMb = totalMb,
            availableMb = availableMb,
            lowMemory = memInfo.lowMemory
        )
    }

    fun readCpuTelemetry(): CpuTelemetry {
        val cores = Runtime.getRuntime().availableProcessors()
        val clockMhz = runCatching {
            val freqFile = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
            if (freqFile.exists() && freqFile.canRead()) {
                val khz = freqFile.readText().trim().toLongOrNull()
                khz?.div(1000L)?.toInt()
            } else {
                null
            }
        }.getOrNull()

        return CpuTelemetry(
            logicalCores = cores,
            currentClockMhz = clockMhz
        )
    }

    fun readDisplayRefreshRateHz(): Float? {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            ?: return null
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
        return display.mode.refreshRate
    }

    fun readDndState(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return false
        return nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
    }

    fun isPackageInstalled(packageName: String): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    packageName,
                    PackageManager.PackageInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
            true
        }.getOrDefault(false)
    }

    fun detectForegroundSupportedGame(): SupportedGame? {
        val usageStatsManager =
            context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                ?: return null

        val endTime = System.currentTimeMillis()
        val startTime = endTime - 15_000L
        val events = usageStatsManager.queryEvents(startTime, endTime)
        val event = UsageEvents.Event()
        var latestPackage: String? = null
        var latestTimestamp = 0L

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val isResumed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }
            if (isResumed && event.timeStamp >= latestTimestamp) {
                latestTimestamp = event.timeStamp
                latestPackage = event.packageName
            }
        }

        return SupportedGame.entries.firstOrNull { it.packageName == latestPackage }
    }
}
